
let filtered = questions;

const container = document.getElementById("questionContainer");
const search = document.getElementById("search");
const filter = document.getElementById("difficultyFilter");

function render(){
container.innerHTML="";

filtered.forEach((q,i)=>{

let saved = localStorage.getItem("answer_"+i) || "";

container.innerHTML += `
<div class="card">
<h3>Question</h3>
<p>${q.q}</p>
<p><b>Difficulty:</b> ${q.difficulty}</p>

<textarea placeholder="Write your answer..." 
oninput="saveAnswer(${i}, this.value)">${saved}</textarea>
</div>
`
})

updateStats();
}

function saveAnswer(i,val){
localStorage.setItem("answer_"+i,val);
updateStats();
}

function updateStats(){

let answered=0;

questions.forEach((q,i)=>{
if(localStorage.getItem("answer_"+i)) answered++;
})

document.getElementById("stats").innerHTML=
`<b>Progress:</b> ${answered}/${questions.length} questions answered`
}

search.addEventListener("input",()=>{

let term=search.value.toLowerCase();

filtered = questions.filter(q=>q.q.toLowerCase().includes(term));

applyDifficulty();

})

filter.addEventListener("change",applyDifficulty);

function applyDifficulty(){

let diff = filter.value;

filtered = questions.filter(q=>{

let matchSearch = q.q.toLowerCase().includes(search.value.toLowerCase());

let matchDiff = diff==="all" || q.difficulty===diff;

return matchSearch && matchDiff;

})

render();
}

function startMock(){

let q = questions[Math.floor(Math.random()*questions.length)];

alert("Mock Interview Question:\n\n"+q.q);

}

function toggleDarkMode(){
document.body.classList.toggle("dark");
}

render();
