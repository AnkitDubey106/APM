const questions = [
  {
    "q": "Tell me about a product you love and how you would improve it",
    "difficulty": "easy"
  },
  {
    "q": "How would you improve Uber's driver experience?",
    "difficulty": "medium"
  },
  {
    "q": "Design a product for remote team collaboration",
    "difficulty": "medium"
  },
  {
    "q": "How would you increase retention for Spotify?",
    "difficulty": "hard"
  },
  {
    "q": "How would you monetize WhatsApp without ads?",
    "difficulty": "hard"
  },
  {
    "q": "How would you prioritize product features?",
    "difficulty": "easy"
  },
  {
    "q": "How do you measure product success?",
    "difficulty": "easy"
  },
  {
    "q": "Explain a time you handled customer feedback",
    "difficulty": "easy"
  },
  {
    "q": "How would you reduce delivery time for Amazon?",
    "difficulty": "medium"
  },
  {
    "q": "Design a product for students preparing for exams",
    "difficulty": "medium"
  },
  {
    "q": "How would you improve LinkedIn engagement?",
    "difficulty": "hard"
  },
  {
    "q": "What metrics would you track for Instagram Reels?",
    "difficulty": "hard"
  }
]